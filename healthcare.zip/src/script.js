// Hospital data structure
const hospitals = [
  // Add all hospitals from your HTML with their coordinates
  {
    name: "Apollo Hospital",
    location: { lat: 19.0176147, lng: 72.8561644 },
    address: "Mumbai, Maharashtra"
  },
  // Add more hospitals...
];

// Initialize the map and get user location
let map;
let userMarker;
let hospitalMarkers = [];

function initMap() {
  // Create map centered on Maharashtra
  map = new google.maps.Map(document.getElementById('map'), {
    center: { lat: 19.7515, lng: 75.7139 },
    zoom: 7
  });

  // Get user's location when they click the button
  document.getElementById('viewLocation').addEventListener('click', getUserLocation);
}

function getUserLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };

        // Center map on user location
        map.setCenter(userLocation);
        map.setZoom(12);

        // Add user marker
        if (userMarker) userMarker.setMap(null);
        userMarker = new google.maps.Marker({
          position: userLocation,
          map: map,
          title: 'Your Location',
          icon: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png'
        });

        // Find and display nearby hospitals
        findNearbyHospitals(userLocation);
      },
      (error) => {
        console.error("Error getting location:", error);
        alert("Error getting your location. Please check your browser settings.");
      }
    );
  } else {
    alert("Geolocation is not supported by your browser.");
  }
}

function findNearbyHospitals(userLocation) {
  // Clear existing markers
  hospitalMarkers.forEach(marker => marker.setMap(null));
  hospitalMarkers = [];

  // Calculate distances and sort hospitals
  const nearbyHospitals = hospitals
    .map(hospital => ({
      ...hospital,
      distance: getDistance(userLocation, hospital.location)
    }))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, 10); // Show 10 nearest hospitals

  // Add markers for nearby hospitals
  nearbyHospitals.forEach(hospital => {
    const marker = new google.maps.Marker({
      position: hospital.location,
      map: map,
      title: hospital.name
    });

    const infoWindow = new google.maps.InfoWindow({
      content: `
        <h3>${hospital.name}</h3>
        <p>${hospital.address}</p>
        <p>Distance: ${(hospital.distance).toFixed(2)} km</p>
      `
    });

    marker.addListener('click', () => {
      infoWindow.open(map, marker);
    });

    hospitalMarkers.push(marker);
  });

  // Update the hospital list in the sidebar
  updateHospitalList(nearbyHospitals);
}

function getDistance(point1, point2) {
  const R = 6371; // Earth's radius in km
  const dLat = toRad(point2.lat - point1.lat);
  const dLon = toRad(point2.lng - point1.lng);
  const lat1 = toRad(point1.lat);
  const lat2 = toRad(point2.lat);

  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function toRad(value) {
  return value * Math.PI / 180;
}

function updateHospitalList(hospitals) {
  const list = document.getElementById('hospital-list');
  list.innerHTML = hospitals.map(hospital => `
    <li class="list-group-item">
      <h5>${hospital.name}</h5>
      <p>${hospital.address}</p>
      <p>Distance: ${hospital.distance.toFixed(2)} km</p>
    </li>
  `).join('');
}